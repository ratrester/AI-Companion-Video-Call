import { useEffect, useRef, useState, useCallback } from 'react';
import { io, Socket } from 'socket.io-client';

interface WebRTCConfig {
  iceServers: RTCIceServer[];
}

interface UseWebRTCProps {
  roomId: string;
  userId: string;
  onMessage?: (message: { from: string; text: string; timestamp: string }) => void;
  onConnectionStateChange?: (state: RTCPeerConnectionState) => void;
}

export const useWebRTC = ({
  roomId,
  userId,
  onMessage,
  onConnectionStateChange,
}: UseWebRTCProps) => {
  const [isConnected, setIsConnected] = useState(false);
  const [isConnecting, setIsConnecting] = useState(false);
  const [localStream, setLocalStream] = useState<MediaStream | null>(null);
  const [remoteStream, setRemoteStream] = useState<MediaStream | null>(null);
  const [isMuted, setIsMuted] = useState(false);
  const [isCameraOff, setIsCameraOff] = useState(false);

  const socketRef = useRef<Socket | null>(null);
  const peerConnectionRef = useRef<RTCPeerConnection | null>(null);
  const localStreamRef = useRef<MediaStream | null>(null);

  // Initialize WebRTC configuration
  const initializeWebRTC = useCallback(async () => {
    try {
      // Fetch WebRTC configuration from backend
      const response = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/api/webrtc/config`);
      const config: WebRTCConfig = await response.json();

      // Create peer connection
      const peerConnection = new RTCPeerConnection(config);
      peerConnectionRef.current = peerConnection;

      // Handle connection state changes
      peerConnection.onconnectionstatechange = () => {
        const state = peerConnection.connectionState;
        console.log('Connection state:', state);

        setIsConnected(state === 'connected');
        setIsConnecting(state === 'connecting');

        if (onConnectionStateChange) {
          onConnectionStateChange(state);
        }
      };

      // Handle remote stream
      peerConnection.ontrack = (event) => {
        console.log('Received remote track');
        const [stream] = event.streams;
        setRemoteStream(stream);
      };

      // Handle ICE candidates
      peerConnection.onicecandidate = (event) => {
        if (event.candidate && socketRef.current) {
          socketRef.current.emit('candidate', {
            roomId,
            candidate: event.candidate,
          });
        }
      };

      return peerConnection;
    } catch (error) {
      console.error('Error initializing WebRTC:', error);
      throw error;
    }
  }, [roomId, onConnectionStateChange]);

  // Initialize Socket.IO
  const initializeSocket = useCallback(() => {
    const socket = io(process.env.NEXT_PUBLIC_SOCKET_URL || 'http://localhost:8000');
    socketRef.current = socket;

    socket.on('connect', () => {
      console.log('Socket connected');
      socket.emit('join', { roomId, userId, role: 'user' });
    });

    socket.on('user_joined', (data) => {
      console.log('User joined:', data);
    });

    socket.on('offer', async (data) => {
      console.log('Received offer');
      if (peerConnectionRef.current) {
        await peerConnectionRef.current.setRemoteDescription(data.sdp);
        const answer = await peerConnectionRef.current.createAnswer();
        await peerConnectionRef.current.setLocalDescription(answer);

        socket.emit('answer', {
          roomId,
          sdp: answer,
        });
      }
    });

    socket.on('answer', async (data) => {
      console.log('Received answer');
      if (peerConnectionRef.current) {
        await peerConnectionRef.current.setRemoteDescription(data.sdp);
      }
    });

    socket.on('candidate', async (data) => {
      if (peerConnectionRef.current) {
        await peerConnectionRef.current.addIceCandidate(data.candidate);
      }
    });

    socket.on('message', (message) => {
      if (onMessage) {
        onMessage(message);
      }
    });

    socket.on('call_ended', () => {
      console.log('Call ended by remote peer');
      endCall();
    });

    socket.on('disconnect', () => {
      console.log('Socket disconnected');
      setIsConnected(false);
    });

    return socket;
  }, [roomId, userId, onMessage]);

  // Start local media
  const startLocalMedia = useCallback(async (constraints?: MediaStreamConstraints) => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia(
        constraints || { video: true, audio: true }
      );

      localStreamRef.current = stream;
      setLocalStream(stream);

      // Add tracks to peer connection
      if (peerConnectionRef.current) {
        stream.getTracks().forEach((track) => {
          peerConnectionRef.current?.addTrack(track, stream);
        });
      }

      return stream;
    } catch (error) {
      console.error('Error accessing media devices:', error);
      throw error;
    }
  }, []);

  // Create offer
  const createOffer = useCallback(async () => {
    if (peerConnectionRef.current && socketRef.current) {
      const offer = await peerConnectionRef.current.createOffer();
      await peerConnectionRef.current.setLocalDescription(offer);

      socketRef.current.emit('offer', {
        roomId,
        sdp: offer,
      });
    }
  }, [roomId]);

  // Toggle microphone
  const toggleMic = useCallback((enabled: boolean) => {
    if (localStreamRef.current) {
      const audioTracks = localStreamRef.current.getAudioTracks();
      audioTracks.forEach((track) => {
        track.enabled = enabled;
      });
      setIsMuted(!enabled);
    }
  }, []);

  // Toggle camera
  const toggleCamera = useCallback((enabled: boolean) => {
    if (localStreamRef.current) {
      const videoTracks = localStreamRef.current.getVideoTracks();
      videoTracks.forEach((track) => {
        track.enabled = enabled;
      });
      setIsCameraOff(!enabled);
    }
  }, []);

  // Send chat message
  const sendMessage = useCallback((text: string) => {
    if (socketRef.current) {
      socketRef.current.emit('message', {
        roomId,
        from: 'user',
        text,
      });
    }
  }, [roomId]);

  // End call
  const endCall = useCallback(() => {
    // Stop local stream
    if (localStreamRef.current) {
      localStreamRef.current.getTracks().forEach((track) => track.stop());
      localStreamRef.current = null;
      setLocalStream(null);
    }

    // Close peer connection
    if (peerConnectionRef.current) {
      peerConnectionRef.current.close();
      peerConnectionRef.current = null;
    }

    // Disconnect socket
    if (socketRef.current) {
      socketRef.current.emit('end', { roomId, reason: 'user_ended' });
      socketRef.current.disconnect();
      socketRef.current = null;
    }

    setRemoteStream(null);
    setIsConnected(false);
    setIsConnecting(false);
  }, [roomId]);

  // Initialize everything on mount
  useEffect(() => {
    const initialize = async () => {
      try {
        setIsConnecting(true);

        // Initialize socket
        initializeSocket();

        // Initialize WebRTC
        await initializeWebRTC();

        // Start local media
        await startLocalMedia();

        // Small delay before creating offer
        setTimeout(createOffer, 1000);

      } catch (error) {
        console.error('Error initializing call:', error);
        setIsConnecting(false);
      }
    };

    initialize();

    // Cleanup on unmount
    return () => {
      endCall();
    };
  }, [roomId, userId]);

  return {
    localStream,
    remoteStream,
    isConnected,
    isConnecting,
    isMuted,
    isCameraOff,
    toggleMic,
    toggleCamera,
    sendMessage,
    endCall,
  };
};
