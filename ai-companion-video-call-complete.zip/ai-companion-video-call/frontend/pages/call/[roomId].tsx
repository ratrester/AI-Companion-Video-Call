import React, { useEffect, useState } from 'react';
import { useRouter } from 'next/router';
import VideoCallModal from '../../components/VideoCallModal';

interface Companion {
  id: string;
  name: string;
  avatarUrl: string;
  description?: string;
  personality?: string;
}

const CallRoomPage: React.FC = () => {
  const router = useRouter();
  const { roomId, companionId, userId } = router.query;
  const [companion, setCompanion] = useState<Companion | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!roomId || !companionId || !userId) return;

    const fetchCompanionData = async () => {
      try {
        // Validate room first
        const roomResponse = await fetch(
          `${process.env.NEXT_PUBLIC_API_URL}/api/video/rooms/${roomId}`
        );

        if (!roomResponse.ok) {
          throw new Error('Room not found or expired');
        }

        // Fetch companion data
        const companionsResponse = await fetch(
          `${process.env.NEXT_PUBLIC_API_URL}/api/companions`
        );

        if (!companionsResponse.ok) {
          throw new Error('Failed to fetch companion data');
        }

        const companionsData = await companionsResponse.json();
        const selectedCompanion = companionsData.companions.find(
          (c: Companion) => c.id === companionId
        );

        if (!selectedCompanion) {
          throw new Error('Companion not found');
        }

        setCompanion(selectedCompanion);
      } catch (err) {
        setError(err instanceof Error ? err.message : 'An error occurred');
        console.error('Error fetching data:', err);
      } finally {
        setLoading(false);
      }
    };

    fetchCompanionData();
  }, [roomId, companionId, userId]);

  const handleCallEnd = (recordingBlob?: Blob) => {
    // Handle call ending
    console.log('Call ended', { recordingBlob });

    // Navigate back to companions page
    router.push('/companions');
  };

  const handleMessage = (message: { from: 'user' | 'companion'; text: string }) => {
    console.log('New message:', message);
    // Handle incoming messages if needed
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-black flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-16 w-16 border-b-2 border-white mx-auto"></div>
          <p className="mt-4 text-white">Preparing your call...</p>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen bg-black flex items-center justify-center">
        <div className="text-center">
          <div className="bg-red-900 border border-red-700 text-red-100 px-6 py-4 rounded-lg">
            <h2 className="font-bold text-xl mb-2">Call Error</h2>
            <p>{error}</p>
            <button
              onClick={() => router.push('/companions')}
              className="mt-4 px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700 transition-colors"
            >
              Return to Companions
            </button>
          </div>
        </div>
      </div>
    );
  }

  if (!companion) {
    return (
      <div className="min-h-screen bg-black flex items-center justify-center">
        <div className="text-center">
          <p className="text-white">Companion not found</p>
          <button
            onClick={() => router.push('/companions')}
            className="mt-4 px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700 transition-colors"
          >
            Return to Companions
          </button>
        </div>
      </div>
    );
  }

  return (
    <VideoCallModal
      roomId={roomId as string}
      userId={userId as string}
      companion={companion}
      onEnd={handleCallEnd}
      onMessage={handleMessage}
      captions={false}
    />
  );
};

export default CallRoomPage;
