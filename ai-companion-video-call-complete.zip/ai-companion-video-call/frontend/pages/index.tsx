import React from 'react';
import { useRouter } from 'next/router';
import { Video, Users, Sparkles, ArrowRight } from 'lucide-react';

const HomePage: React.FC = () => {
  const router = useRouter();

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-indigo-50 to-purple-50">
      {/* Hero Section */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="pt-20 pb-16 text-center lg:pt-32">
          <div className="mx-auto max-w-4xl">
            <div className="mb-8">
              <div className="inline-flex items-center space-x-3 bg-white/80 backdrop-blur-sm rounded-full px-6 py-3 shadow-lg">
                <Video className="w-6 h-6 text-blue-500" />
                <span className="text-sm font-medium text-gray-900">AI Companion Video Calls</span>
              </div>
            </div>

            <h1 className="text-4xl font-bold tracking-tight text-gray-900 sm:text-6xl">
              Connect with
              <span className="text-blue-600"> AI Companions</span>
            </h1>

            <p className="mt-6 text-xl leading-8 text-gray-600 max-w-2xl mx-auto">
              Experience the future of interaction with our AI companions. 
              Engage in meaningful video conversations with intelligent, personalized AI tutors 
              and assistants tailored to your needs.
            </p>

            <div className="mt-10 flex flex-col sm:flex-row items-center justify-center gap-4">
              <button
                onClick={() => router.push('/companions')}
                className="group inline-flex items-center justify-center rounded-full bg-blue-600 px-8 py-4 text-lg font-semibold text-white shadow-lg hover:bg-blue-700 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-blue-600 transition-all duration-200"
              >
                Get Started
                <ArrowRight className="ml-2 w-5 h-5 group-hover:translate-x-1 transition-transform" />
              </button>

              <button className="inline-flex items-center justify-center rounded-full border border-gray-300 bg-white/80 backdrop-blur-sm px-8 py-4 text-lg font-semibold text-gray-900 shadow hover:bg-white focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-gray-600 transition-colors">
                Learn More
              </button>
            </div>
          </div>
        </div>

        {/* Features Section */}
        <section className="pb-20">
          <div className="mx-auto max-w-2xl text-center">
            <h2 className="text-3xl font-bold tracking-tight text-gray-900 sm:text-4xl">
              Why Choose AI Companions?
            </h2>
            <p className="mt-4 text-lg text-gray-600">
              Experience next-generation AI interaction with cutting-edge technology
            </p>
          </div>

          <div className="mx-auto mt-16 max-w-5xl">
            <div className="grid grid-cols-1 gap-8 sm:grid-cols-2 lg:grid-cols-3">
              {/* Feature 1 */}
              <div className="group relative bg-white/60 backdrop-blur-sm rounded-2xl p-8 shadow-lg hover:shadow-xl transition-all duration-300 hover:-translate-y-1">
                <div className="flex items-center justify-center w-16 h-16 bg-blue-100 rounded-xl mb-6 mx-auto group-hover:bg-blue-200 transition-colors">
                  <Video className="w-8 h-8 text-blue-600" />
                </div>
                <h3 className="text-xl font-semibold text-gray-900 mb-4 text-center">
                  HD Video Calls
                </h3>
                <p className="text-gray-600 text-center">
                  Crystal-clear video communication powered by WebRTC technology 
                  for seamless real-time interactions.
                </p>
              </div>

              {/* Feature 2 */}
              <div className="group relative bg-white/60 backdrop-blur-sm rounded-2xl p-8 shadow-lg hover:shadow-xl transition-all duration-300 hover:-translate-y-1">
                <div className="flex items-center justify-center w-16 h-16 bg-green-100 rounded-xl mb-6 mx-auto group-hover:bg-green-200 transition-colors">
                  <Users className="w-8 h-8 text-green-600" />
                </div>
                <h3 className="text-xl font-semibold text-gray-900 mb-4 text-center">
                  Diverse Personalities
                </h3>
                <p className="text-gray-600 text-center">
                  Choose from a variety of AI companions, each with unique expertise, 
                  personalities, and conversational styles.
                </p>
              </div>

              {/* Feature 3 */}
              <div className="group relative bg-white/60 backdrop-blur-sm rounded-2xl p-8 shadow-lg hover:shadow-xl transition-all duration-300 hover:-translate-y-1">
                <div className="flex items-center justify-center w-16 h-16 bg-purple-100 rounded-xl mb-6 mx-auto group-hover:bg-purple-200 transition-colors">
                  <Sparkles className="w-8 h-8 text-purple-600" />
                </div>
                <h3 className="text-xl font-semibold text-gray-900 mb-4 text-center">
                  AI-Powered Intelligence
                </h3>
                <p className="text-gray-600 text-center">
                  Advanced AI technology ensures meaningful, context-aware conversations 
                  tailored to your interests and needs.
                </p>
              </div>
            </div>
          </div>
        </section>

        {/* Stats Section */}
        <section className="pb-20">
          <div className="bg-white/40 backdrop-blur-sm rounded-3xl p-8 shadow-lg">
            <div className="grid grid-cols-1 gap-8 sm:grid-cols-3 text-center">
              <div>
                <div className="text-4xl font-bold text-blue-600 mb-2">24/7</div>
                <div className="text-lg font-semibold text-gray-900">Always Available</div>
                <div className="text-gray-600">Your AI companions are ready whenever you are</div>
              </div>

              <div>
                <div className="text-4xl font-bold text-green-600 mb-2">HD</div>
                <div className="text-lg font-semibold text-gray-900">Video Quality</div>
                <div className="text-gray-600">Crystal-clear video and audio experience</div>
              </div>

              <div>
                <div className="text-4xl font-bold text-purple-600 mb-2">∞</div>
                <div className="text-lg font-semibold text-gray-900">Unlimited Potential</div>
                <div className="text-gray-600">Endless learning and conversation opportunities</div>
              </div>
            </div>
          </div>
        </section>
      </main>

      {/* Footer */}
      <footer className="bg-white/80 backdrop-blur-sm">
        <div className="mx-auto max-w-7xl px-6 py-12 md:flex md:items-center md:justify-between lg:px-8">
          <div className="flex justify-center space-x-6 md:order-2">
            <p className="text-center text-sm leading-5 text-gray-500">
              &copy; 2024 AI Companion Platform. Powered by WebRTC & Advanced AI.
            </p>
          </div>
          <div className="mt-8 md:order-1 md:mt-0">
            <div className="flex items-center justify-center md:justify-start">
              <Video className="w-6 h-6 text-blue-600 mr-2" />
              <span className="font-semibold text-gray-900">AI Companions</span>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default HomePage;
