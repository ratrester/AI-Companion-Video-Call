from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
import socketio
import uvicorn
import os
from dotenv import load_dotenv
import redis
import httpx
import uuid
from datetime import datetime, timedelta
from typing import Dict, List, Optional
import asyncio
import logging

# Load environment variables
load_dotenv()

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Initialize FastAPI app
app = FastAPI(
    title="AI Companion Video Call API",
    description="Backend API for AI companion video calling platform",
    version="1.0.0"
)

# CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=os.getenv("CORS_ORIGINS", "http://localhost:3000").split(","),
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Initialize Redis
try:
    redis_client = redis.from_url(os.getenv("REDIS_URL", "redis://localhost:6379"))
    redis_client.ping()
    logger.info("Redis connection established")
except Exception as e:
    logger.error(f"Redis connection failed: {e}")
    redis_client = None

# Initialize Socket.IO
sio = socketio.AsyncServer(
    async_mode='asgi',
    cors_allowed_origins="*",
    logger=True,
    engineio_logger=True
)

# Socket.IO ASGI app
socket_app = socketio.ASGIApp(sio, app)

# In-memory storage for active rooms (use Redis in production)
active_rooms: Dict[str, Dict] = {}
room_participants: Dict[str, List[str]] = {}

class Room:
    def __init__(self, room_id: str, companion_id: str, user_id: str):
        self.room_id = room_id
        self.companion_id = companion_id
        self.user_id = user_id
        self.created_at = datetime.utcnow()
        self.expires_at = self.created_at + timedelta(hours=2)
        self.status = "active"
        self.participants = []

class CompanionService:
    def __init__(self):
        self.persona_api_url = os.getenv(
            "PERSONA_FETCHER_API", 
            "https://persona-fetcher-api.up.railway.app/personas"
        )
        self.cache_key = "companions:all"
        self.cache_ttl = 3600  # 1 hour

    async def get_companions(self) -> List[Dict]:
        """Fetch companions from external API with caching"""
        try:
            # Try to get from cache first
            if redis_client:
                cached_data = redis_client.get(self.cache_key)
                if cached_data:
                    import json
                    logger.info("Returning cached companions data")
                    return json.loads(cached_data)

            # Fetch from external API
            async with httpx.AsyncClient() as client:
                response = await client.get(self.persona_api_url, timeout=10.0)
                response.raise_for_status()
                companions_data = response.json()

                # Cache the data
                if redis_client:
                    import json
                    redis_client.setex(
                        self.cache_key, 
                        self.cache_ttl, 
                        json.dumps(companions_data)
                    )

                logger.info(f"Fetched {len(companions_data)} companions from API")
                return companions_data

        except httpx.TimeoutException:
            logger.error("Timeout fetching companions from external API")
            return self._get_fallback_companions()
        except Exception as e:
            logger.error(f"Error fetching companions: {e}")
            return self._get_fallback_companions()

    def _get_fallback_companions(self) -> List[Dict]:
        """Fallback companions data if external API fails"""
        return [
            {
                "id": "companion-1",
                "name": "Sarah",
                "description": "Friendly AI tutor specializing in mathematics",
                "avatarUrl": "https://images.unsplash.com/photo-1494790108755-2616c6c9b0ec?w=400",
                "voiceId": "EXAVITQu4vr4xnSDxMaL",
                "expertise": ["Mathematics", "Physics", "Science"],
                "personality": "Patient and encouraging"
            }
        ]

# Initialize services
companion_service = CompanionService()

# API Routes
@app.get("/")
async def root():
    return {"message": "AI Companion Video Call API", "status": "running"}

@app.get("/api/companions")
async def get_companions():
    """Get all available AI companions"""
    companions = await companion_service.get_companions()
    return {"companions": companions}

if __name__ == "__main__":
    uvicorn.run(
        "main:socket_app",
        host=os.getenv("API_HOST", "0.0.0.0"),
        port=int(os.getenv("API_PORT", 8000)),
        reload=True
    )
