# AI Companion Video Call & Streaming Platform

A real-time video calling application enabling users to connect with AI companions through WebRTC-powered peer-to-peer video calls.

## Features

- **Companion Selection**: Browse AI personas with images, metadata, and voice profiles
- **WebRTC Video Calls**: Real-time peer-to-peer video communication
- **Real-time Chat**: Instant messaging during video calls
- **Call Controls**: Mute/unmute, camera toggle, call timer, captions
- **Responsive Design**: Works across desktop and mobile devices

## Tech Stack

### Frontend
- **Framework**: Next.js 14 with TypeScript
- **Styling**: Tailwind CSS
- **WebRTC**: Native WebRTC APIs with Socket.IO signaling
- **State Management**: React hooks and context

### Backend
- **Framework**: FastAPI (Python)
- **Real-time**: Socket.IO for WebRTC signaling
- **AI Integration**: Google Gemini, LangMem
- **Caching**: Redis
- **Database**: PostgreSQL (optional)

## Setup Instructions

### Prerequisites
- Node.js 18+
- Python 3.9+
- Redis server
- FFmpeg (for video recording features)

### Environment Variables

Create `.env.local` in the frontend directory:
```env
NEXT_PUBLIC_API_URL=http://localhost:8000
NEXT_PUBLIC_SOCKET_URL=http://localhost:8000
NEXT_PUBLIC_STUN_SERVER=stun:stun.l.google.com:19302
```

Create `.env` in the backend directory:
```env
# API Configuration
API_HOST=0.0.0.0
API_PORT=8000
DEBUG=true

# External APIs
PERSONA_FETCHER_API=https://persona-fetcher-api.up.railway.app/personas
ELEVENLABS_API_KEY=your_elevenlabs_key
GEMINI_API_KEY=your_gemini_key

# Redis Configuration
REDIS_URL=redis://localhost:6379

# WebRTC Configuration
STUN_SERVER=stun:stun.l.google.com:19302
TURN_SERVER_URL=turn:global.turn.twilio.com:3478
TURN_USERNAME=your_turn_username
TURN_CREDENTIAL=your_turn_credential

# Security
SECRET_KEY=your-secret-key
CORS_ORIGINS=["http://localhost:3000"]
```

### Installation & Running

1. **Clone and setup the project**:
```bash
git clone <your-repo>
cd ai-companion-video-call
```

2. **Frontend Setup**:
```bash
cd frontend
npm install
npm run dev
```

3. **Backend Setup**:
```bash
cd backend
pip install -r requirements.txt
uvicorn app.main:app --reload --host 0.0.0.0 --port 8000
```

4. **Redis Setup**:
```bash
# Install Redis
brew install redis  # macOS
sudo apt install redis-server  # Ubuntu

# Start Redis
redis-server
```

### TURN Server Notes

For production deployment, configure TURN servers for NAT traversal:

**Recommended TURN Providers**:
- **Twilio**: `turn:global.turn.twilio.com:3478`
- **LiveKit**: Professional WebRTC infrastructure
- **Agora**: Scalable real-time communication

**Free STUN Server**: `stun:stun.l.google.com:19302`

## Demo Steps

1. **Start the Application**:
   - Backend: `uvicorn app.main:app --reload`
   - Frontend: `npm run dev`
   - Redis: `redis-server`

2. **Test Video Calling**:
   - Navigate to `http://localhost:3000`
   - Select an AI companion
   - Initiate video call
   - Test mic/camera controls
   - Try the chat functionality

3. **Test Multi-user**:
   - Open multiple browser windows
   - Create different rooms
   - Test WebRTC peer connections

## API Documentation

Once running, visit:
- **Interactive API Docs**: http://localhost:8000/docs
- **ReDoc**: http://localhost:8000/redoc

## Architecture

See `docs/architecture.md` for detailed system design, sequence diagrams, and technical decisions.

## Development

### Code Structure
```
frontend/
├── components/          # React components
├── hooks/              # Custom React hooks
├── pages/              # Next.js pages
└── styles/             # CSS styles

backend/
├── app/
│   ├── api/            # API endpoints
│   ├── core/           # Configuration
│   ├── models/         # Data models
│   └── services/       # Business logic
└── docs/               # Documentation
```

### Key Components
- `VideoCallModal.tsx`: Main video call interface
- `useWebRTC.ts`: WebRTC hook for media handling
- `companions/index.tsx`: Companion selection page

### Testing
```bash
# Frontend tests
cd frontend && npm test

# Backend tests
cd backend && pytest

# E2E tests
npm run test:e2e
```

## Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Add tests
5. Submit a pull request

## License

MIT License - see LICENSE file for details.
