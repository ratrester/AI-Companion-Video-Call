# Architecture Documentation

## System Overview

The AI Companion Video Call platform consists of a Next.js frontend, FastAPI backend, and WebRTC infrastructure for real-time communication.

```mermaid
graph TB
    User[User Browser] --> Frontend[Next.js Frontend]
    Frontend --> Backend[FastAPI Backend]
    Backend --> PersonaAPI[Persona Fetcher API]
    Backend --> Redis[(Redis Cache)]
    Backend --> Gemini[Google Gemini AI]

    Frontend <--> SignalServer[Socket.IO Signaling]
    SignalServer --> Backend

    User <--> STUN[STUN Server]
    User <--> TURN[TURN Server]

    Frontend --> WebRTC[WebRTC Connection]
    WebRTC --> Companion[AI Companion]
```

## Component Architecture

### Frontend Components

1. **CompanionSelector** (`/companions`)
   - Fetches companion data from `/api/companions`
   - Displays companion cards with metadata
   - Handles companion selection and room creation

2. **VideoCallModal** (`components/VideoCallModal.tsx`)
   - Main video call interface
   - Manages WebRTC connections
   - Handles media controls and chat

3. **useWebRTC Hook** (`hooks/useWebRTC.ts`)
   - Encapsulates WebRTC logic
   - Manages peer connections
   - Handles signaling events

### Backend Services

1. **API Router** (`/api/*`)
   - REST endpoints for room management
   - Companion data proxy
   - WebRTC configuration

2. **Socket.IO Handler** (`/signal`)
   - WebRTC signaling server
   - Room-based event handling
   - Peer connection orchestration

3. **Companion Service**
   - Proxies external persona API
   - Caches companion data
   - Validates companion metadata

## Sequence Diagrams

### 1. Companion Selection Flow

```mermaid
sequenceDiagram
    participant User
    participant Frontend
    participant Backend
    participant PersonaAPI

    User->>Frontend: Visit /companions
    Frontend->>Backend: GET /api/companions
    Backend->>PersonaAPI: Fetch personas
    PersonaAPI-->>Backend: Return persona data
    Backend-->>Frontend: Cached companion list
    Frontend-->>User: Display companions

    User->>Frontend: Select companion
    Frontend->>Backend: POST /api/video/rooms
    Backend-->>Frontend: { roomId, companionId }
    Frontend->>Frontend: Navigate to /call/[roomId]
```

### 2. WebRTC Signaling Flow

```mermaid
sequenceDiagram
    participant User
    participant Frontend
    participant SignalServer
    participant Companion

    User->>Frontend: Join video call
    Frontend->>SignalServer: emit('join', { roomId, userId })

    Frontend->>SignalServer: emit('offer', { roomId, sdp })
    SignalServer->>Companion: forward offer

    Companion->>SignalServer: emit('answer', { roomId, sdp })
    SignalServer->>Frontend: forward answer

    Frontend<->Companion: ICE candidate exchange
    Frontend<->Companion: Direct P2P media flow
```

### 3. Media Flow Architecture

```mermaid
graph LR
    User[User Browser] --> LocalMedia[Local MediaStream]
    LocalMedia --> PeerConnection[RTCPeerConnection]

    PeerConnection <--> STUN[STUN Server<br/>NAT Discovery]
    PeerConnection <--> TURN[TURN Server<br/>Relay if needed]

    PeerConnection <--> CompanionPeer[Companion Peer]
    CompanionPeer --> CompanionMedia[AI Companion Stream]

    PeerConnection --> RemoteMedia[Remote MediaStream]
    RemoteMedia --> VideoElement[Video Element]
```

## Design Decisions

### WebRTC Implementation

**Decision**: Direct peer-to-peer connections with fallback to TURN
- **Rationale**: Reduces server load and latency
- **Trade-offs**: More complex NAT handling
- **Alternatives**: SFU (Selective Forwarding Unit) for scalability

**STUN/TURN Configuration**:
```javascript
const rtcConfig = {
  iceServers: [
    { urls: 'stun:stun.l.google.com:19302' },
    { 
      urls: 'turn:global.turn.twilio.com:3478',
      username: process.env.TURN_USERNAME,
      credential: process.env.TURN_CREDENTIAL
    }
  ]
};
```

### Signaling Strategy

**Decision**: Socket.IO for real-time signaling
- **Rationale**: Reliable WebSocket with fallbacks
- **Benefits**: Room-based event handling, reconnection
- **Alternatives**: Pure WebSocket, Server-Sent Events

### AI Companion Integration

**Decision**: Proxy external persona API
- **Rationale**: Centralized data management and caching
- **Benefits**: Consistent API, Redis caching, data validation
- **Implementation**: FastAPI middleware with Redis caching

### State Management

**Decision**: React hooks with local state
- **Rationale**: Simple, sufficient for app complexity
- **Benefits**: No external dependencies, type-safe
- **Alternatives**: Redux, Zustand for complex state

### Media Handling

**Decision**: Native WebRTC APIs
- **Rationale**: Maximum control and performance
- **Trade-offs**: More complex implementation
- **Libraries Considered**: SimpleWebRTC, PeerJS (rejected for flexibility)

## Scalability Considerations

### Current Architecture Limitations
- Single signaling server
- Direct P2P only
- No media recording persistence

### Scaling Strategies

1. **Horizontal Scaling**
   ```mermaid
   graph TB
       LB[Load Balancer] --> API1[API Server 1]
       LB --> API2[API Server 2]
       LB --> API3[API Server 3]

       API1 --> Redis[(Redis Cluster)]
       API2 --> Redis
       API3 --> Redis
   ```

2. **SFU Integration** (For >2 participants)
   - LiveKit for managed WebRTC infrastructure
   - Agora for global scaling
   - Self-hosted Mediasoup for control

3. **Media Server Architecture**
   ```mermaid
   graph TB
       Users --> SFU[Selective Forwarding Unit]
       SFU --> Recording[Recording Service]
       SFU --> Analytics[Analytics Pipeline]
       SFU --> AI[AI Processing Service]
   ```

## Security Considerations

### WebRTC Security
- ICE candidate validation
- DTLS encryption (automatic)
- SRTP media encryption
- Origin validation

### API Security
- CORS configuration
- Rate limiting
- Input validation
- JWT authentication (future)

### Data Privacy
- No persistent video storage
- Encrypted peer connections
- Companion data caching policies
- User consent management

## Performance Optimizations

### Frontend
- Component lazy loading
- Image optimization
- WebRTC connection pooling
- Efficient re-renders

### Backend
- Redis caching layer
- Async request handling
- Connection pooling
- Rate limiting

### Network
- ICE candidate optimization
- Bandwidth adaptation
- Quality of service monitoring
- Fallback strategies

## Monitoring & Observability

### Metrics to Track
- WebRTC connection success rate
- Media quality (bitrate, packet loss)
- API response times
- User engagement metrics

### Logging Strategy
- Structured logging (JSON)
- WebRTC event tracking
- Error aggregation
- Performance monitoring

### Tools Integration
- Frontend: Sentry for error tracking
- Backend: Prometheus + Grafana
- WebRTC: Native stats API monitoring

## Deployment Architecture

### Development
```
Frontend (localhost:3000) --> Backend (localhost:8000) --> Redis (localhost:6379)
```

### Production
```mermaid
graph TB
    CDN[CDN/CloudFront] --> Frontend[Next.js App]
    Frontend --> ALB[Application Load Balancer]
    ALB --> API1[FastAPI Instance 1]
    ALB --> API2[FastAPI Instance 2]

    API1 --> Redis[(Redis Cluster)]
    API2 --> Redis

    API1 --> RDS[(PostgreSQL)]
    API2 --> RDS
```

## Future Enhancements

1. **AI Integration**
   - Real-time avatar animation
   - Voice synthesis integration
   - Emotion detection

2. **Advanced Features**
   - Screen sharing
   - Multi-party calls
   - Call recording
   - Virtual backgrounds

3. **Platform Extensions**
   - Mobile apps (React Native)
   - Desktop apps (Electron)
   - Browser extensions

## Testing Strategy

### Unit Tests
- WebRTC hook logic
- API endpoint handlers
- Component rendering

### Integration Tests
- End-to-end call flow
- API contract testing
- Database interactions

### Performance Tests
- Concurrent connection limits
- Media quality under load
- Signaling server capacity
